## Magisk Auto Screenshot Module
A magisk module which takes a screenshot automatically every 10 seconds. The main reason for creating this module is for accountability on my digital devices. Just the knowledge that my behavior is captured and stored changes my phone behavior.

This module works purely offline and stores the files on your phone disk.
